-- Phase 3 behaviors on fake snapshots: wake, recover, pet, follow, rest, removal by item.
local engine = require('core.engine')
local settings = require('core.settings')
local fake = require('tests.fake')

local WHM, RDM, PLD, BLM, SAM, PUP, DRG, MNK = 3, 5, 7, 4, 12, 18, 14, 2
local SLEEP, POISON, INVISIBLE = 2, 3, 69
local OIL = 18731
local snap = fake.snap

local function decide(g, cfg, list, mem)
    cfg = cfg or settings.defaults()
    local intent, why = engine.decide(g, list, cfg, mem or {})
    if not intent then return nil, why end
    return engine.command(intent, cfg), intent
end

local function cfg_with(t)
    local cfg = settings.defaults()
    for path, v in pairs(t) do
        local parent, key = path:match('^(.-)%.([^.]+)$')
        cfg[parent][key] = v
    end
    return cfg
end

-- Wake ----------------------------------------------------------------------------

local whm = fake.catalog(WHM, 75, BLM, 37)

test('wake: the cheapest heal that wakes, on a sleeper at full HP', function ()
    local cmd, intent = decide(snap({ { name = 'A', buffs = { [SLEEP] = true } } }), nil, whm)
    eq({ cmd, intent.behavior, intent.why }, { '/ma "Cure" 101', 'wake', 'A asleep' })
    eq({ decide(snap({ { name = 'A', buffs = { [SLEEP] = true } } }), cfg_with({ ['wake.on'] = false }), whm) },
        { nil, 'nothing to do' })
end)

test('wake: two asleep together get one area heal; spread, the focus member first', function ()
    local two = function (spread)
        return snap({ { name = 'A', buffs = { [SLEEP] = true } },
                      { name = 'B', buffs = { [SLEEP] = true }, pos = spread and { 30, 0, 0 } or nil } })
    end
    local cmd, intent = decide(two(false), nil, whm)
    eq({ cmd, intent.why }, { '/ma "Curaga" 101', '2 asleep' })
    eq(decide(two(true), nil, whm), '/ma "Cure" 101')
    eq(decide(two(true), cfg_with({ ['heal.focus'] = 'B' }), whm), '/ma "Cure" 102')
end)

-- Recover ---------------------------------------------------------------------------

test('recover: Convert under the MP line, only while it gains and you are out of danger', function ()
    local rdm = fake.catalog(RDM, 75, nil, 0, { 'Convert' })
    local cfg = cfg_with({ ['heal.on'] = false })
    local g = snap()
    g.me.mpp, g.me.mp, g.me.hp = 20, 200, 1000
    local cmd, intent = decide(g, cfg, rdm)
    eq({ cmd, intent.why }, { '/ja "Convert" <me>', 'MP 20%' })
    g.me.hpp = 40
    eq({ decide(g, cfg, rdm) }, { nil, 'nothing to do' })
    g.me.hpp, g.me.mpp = 100, 50
    eq({ decide(g, cfg, rdm) }, { nil, 'nothing to do' })
end)

test('recover: Devotion on the member lowest on MP, never one with no MP', function ()
    local cat = fake.catalog(WHM, 75, nil, 0, { 'Devotion' })
    local g = snap({ { name = 'A', mpp = 25 }, { name = 'B', mpp = 10 }, { name = 'War', mpp = 0, uses_mp = false } })
    eq(decide(g, nil, cat), '/ja "Devotion" 102')
    g.units[3].mpp = 50
    eq(decide(g, nil, cat), '/ja "Devotion" 101')
end)

test('recover: Meditate in combat under the TP line; Chivalry from its own TP line', function ()
    local sam = fake.catalog(SAM, 75, nil, 0, { 'Meditate' })
    eq(decide(snap(nil, { combat = true }), nil, sam), '/ja "Meditate" <me>')
    eq({ decide(snap(), nil, sam) }, { nil, 'nothing to do' })
    local pld = fake.catalog(PLD, 75, nil, 0, { 'Chivalry' })
    local cfg = cfg_with({ ['heal.on'] = false })
    local g = snap()
    g.me.mpp, g.me.tp = 20, 2000
    eq({ decide(g, cfg, pld) }, { nil, 'nothing to do' })
    g.me.tp = 3000
    eq(decide(g, cfg, pld), '/ja "Chivalry" <me>')
    g.me.tp, cfg.recover.min_tp = 2000, 1500
    eq(decide(g, cfg, pld), '/ja "Chivalry" <me>')
end)

test('recover: Aspir from the battle target', function ()
    local g = snap(nil, { combat = true, bt = { name = 'Crab', mob = true, dist = 5, hpp = 100 } })
    g.me.mpp = 20
    eq(decide(g, nil, whm), '/ma "Aspir" <bt>')
end)

-- Pet ------------------------------------------------------------------------------

local pup = fake.catalog(PUP, 75, nil, 0, { 'Repair', 'Maintenance', 'Deploy' })
local function automaton(t)
    local p = { name = 'Automaton', hpp = 100, dist = 3, status = 0, buffs = {} }
    for k, v in pairs(t or {}) do p[k] = v end
    return p
end

test('pet: Repair under the pet HP line, only with an oil worn', function ()
    eq({ decide(snap(nil, { pet = automaton({ hpp = 40 }) }), nil, pup) }, { nil, 'nothing to do' })
    local cmd, intent = decide(snap(nil, { pet = automaton({ hpp = 40 }), ammo = OIL }), nil, pup)
    eq({ cmd, intent.behavior, intent.why }, { '/ja "Repair" <me>', 'pet', 'Automaton 40%' })
    eq(decide(snap(nil, { pet = automaton({ hpp = 40 }), ammo = 19185 }), nil, pup), '/ja "Repair" <me>')  -- +3
    eq({ decide(snap(nil, { pet = automaton({ hpp = 60 }), ammo = OIL }), nil, pup) }, { nil, 'nothing to do' })
    local g = snap(nil, { pet = automaton({ hpp = 40 }), ammo = OIL })
    g.me.buffs[INVISIBLE] = true
    eq({ decide(g, nil, pup) }, { nil, 'nothing to do' })
end)

test('pet: Repair only within 20 yalms of the automaton, as the server allows', function ()
    eq({ decide(snap(nil, { pet = automaton({ hpp = 40, dist = 25 }), ammo = OIL }), nil, pup) }, { nil, 'nothing to do' })
end)

test('pet: cared for and sent in while healing waits for a cure', function ()
    local cat = fake.catalog(PUP, 75, WHM, 37, { 'Repair', 'Deploy' })
    local waits = {}
    for _, a in ipairs(cat) do if a.role == 'heal' then waits[a.name] = 5 end end
    local hurt = { { name = 'A', hpp = 45 } }
    eq(decide(snap(hurt, { pet = automaton({ hpp = 40 }), ammo = OIL }, waits), nil, cat), '/ja "Repair" <me>')
    local cfg = settings.defaults()
    cfg.rows.Deploy = { on = true }
    local g = snap(hurt, { pet = automaton(), bt = { name = 'Crab', mob = true, dist = 5, hpp = 100 }, combat = true }, waits)
    eq(decide(g, cfg, cat), '/pet "Deploy" <bt>')
    g.pet = nil
    eq({ decide(g, cfg, cat) }, { nil, 'waiting for a cure' })
end)

test('pet: Maintenance clears what ails it', function ()
    eq(decide(snap(nil, { pet = automaton({ buffs = { [POISON] = true } }), ammo = OIL }), nil, pup),
        '/ja "Maintenance" <me>')
end)

test('pet: sent at the battle target when idle, opt-in', function ()
    local bt = { name = 'Crab', mob = true, dist = 5, hpp = 100 }
    local cfg = settings.defaults()
    eq({ decide(snap(nil, { pet = automaton(), bt = bt, combat = true }), cfg, pup) }, { nil, 'nothing to do' })
    cfg.rows.Deploy = { on = true }
    local cmd, intent = decide(snap(nil, { pet = automaton(), bt = bt, combat = true }), cfg, pup)
    eq({ cmd, intent.behavior }, { '/pet "Deploy" <bt>', 'pet_send' })
    eq({ decide(snap(nil, { pet = automaton({ status = 1 }), bt = bt, combat = true }), cfg, pup) }, { nil, 'nothing to do' })
    eq({ decide(snap(nil, { pet = automaton({ hpp = 0 }), bt = bt, combat = true }), cfg, pup) }, { nil, 'nothing to do' })
end)

test('pet: Spirit Link waits while you are in danger yourself', function ()
    local drg = fake.catalog(DRG, 75, nil, 0, { 'Spirit Link' })
    local g = snap(nil, { pet = automaton({ name = 'Wyvern', hpp = 30 }) })
    eq(decide(g, nil, drg), '/ja "Spirit Link" <me>')
    g.me.hpp = 40
    eq({ decide(g, cfg_with({ ['heal.on'] = false }), drg) }, { nil, 'nothing to do' })
end)

-- Follow and rest -------------------------------------------------------------------------

local function follower()
    return cfg_with({ ['follow.on'] = true, ['follow.target'] = 'a' })
end

test('follow: past the distance, by party slot; not while moving', function ()
    local cmd, intent = decide(snap({ { name = 'B' }, { name = 'A', dist = 8 } }), follower(), whm)
    eq({ cmd, intent.why }, { '/follow <p2>', 'A 8.0y away' })
    eq({ decide(snap({ { name = 'A', dist = 4 } }), follower(), whm) }, { nil, 'nothing to do' })
    eq({ decide(snap({ { name = 'A', dist = 8 } }, { moving = true }), follower(), whm) }, { nil, 'moving' })
end)

test('rest: after the quiet delay, out of combat, MP not full', function ()
    local cfg = cfg_with({ ['rest.on'] = true })
    local g = snap(nil, { moved_at = 990 })
    g.me.mpp = 50
    local cmd, intent = decide(g, cfg, whm)
    eq({ cmd, intent.why }, { '/heal on', 'MP 50%' })
    eq({ decide(g, cfg, whm, { sent_at = 997 }) }, { nil, 'nothing to do' })
    g.moved_at = 998
    eq({ decide(g, cfg, whm) }, { nil, 'nothing to do' })
    g.moved_at, g.combat = 990, true
    eq({ decide(g, cfg, whm) }, { nil, 'nothing to do' })
    g.combat, g.combat_at = false, 997  -- the fight just ended
    eq({ decide(g, cfg, whm) }, { nil, 'nothing to do' })
    g.combat_at, g.me.uses_mp = nil, false
    eq({ decide(g, cfg, whm) }, { nil, 'nothing to do' })
end)

test('resting: nothing else runs; stand at full MP or when the leader leaves', function ()
    local cfg = cfg_with({ ['rest.on'] = true, ['follow.target'] = 'A' })
    local g = snap({ { name = 'A', hpp = 40 } }, { resting = true })
    g.me.mpp = 50
    eq({ decide(g, cfg, whm) }, { nil, 'resting' })
    g.me.mpp = 100
    eq(decide(g, cfg, whm), '/heal off')
    g.me.mpp, g.units[2].dist = 50, 9
    local cmd, intent = decide(g, cfg, whm)
    eq({ cmd, intent.why }, { '/heal off', 'A left' })
end)

-- Removal by item, and the other removers only ever on you --------------------------------

local SILENCE, PARALYSIS, BLINDNESS, BIND, WEIGHT, DOOM = 6, 4, 5, 11, 12, 15
local ANTIDOTE, PANACEA, ECHO_DROPS, REMEDY = 4148, 4149, 4151, 4155

test('items: Echo Drops when silenced, opt-in, only with one in your bag, amnesia or not', function ()
    local g = snap(nil, { silenced = true, amnesia = true, items = { [ECHO_DROPS] = 3 } })
    g.me.buffs[SILENCE] = true
    local cfg = settings.defaults()
    eq({ decide(g, cfg, whm) }, { nil, 'nothing to do' })
    cfg.rows['Echo Drops'] = { on = true }
    local cmd, intent = decide(g, cfg, whm)
    eq({ cmd, intent.behavior, intent.why }, { '/item "Echo Drops" <me>', 'remove', 'Me' })
    g.items = {}
    eq({ decide(g, cfg, whm) }, { nil, 'nothing to do' })
end)

test('items: a spell that can go first; then the most specific item you carry, for you only', function ()
    local cfg = settings.defaults()
    for _, k in ipairs({ 'Antidote', 'Remedy', 'Panacea' }) do cfg.rows[k] = { on = true } end
    local carried = { [ANTIDOTE] = 1, [REMEDY] = 1, [PANACEA] = 1 }
    local g = snap(nil, { items = carried })
    g.me.buffs[POISON] = true
    eq(decide(g, cfg, whm), '/ma "Poisona" <me>')
    local blm = fake.catalog(BLM, 75, nil, 0)
    g = snap({ { name = 'A', buffs = { [POISON] = true } } }, { items = carried })
    eq({ decide(g, cfg, blm) }, { nil, 'nothing to do' })
    g.me.buffs[POISON] = true
    eq(decide(g, cfg, blm), '/item "Antidote" <me>')
    g.me.buffs[POISON], g.me.buffs[PARALYSIS] = nil, true
    eq(decide(g, cfg, blm), '/item "Remedy" <me>')
    carried[REMEDY] = nil
    eq(decide(g, cfg, blm), '/item "Panacea" <me>')
end)

test('items: Doom first, then Silence if you cast, then the one clearing the most of yours', function ()
    local blm = fake.catalog(BLM, 75, nil, 0)
    local cfg, carried = settings.defaults(), {}
    for _, a in ipairs(blm) do if a.kind == 'item' then cfg.rows[a.family] = { on = true }; carried[a.id] = 1 end end
    local g = snap(nil, { items = carried })
    for _, id in ipairs({ DOOM, SILENCE, POISON }) do g.me.buffs[id] = true end
    eq(decide(g, cfg, blm), '/item "Holy Water" <me>')
    g.me.buffs[DOOM] = nil
    eq(decide(g, cfg, blm), '/item "Remedy" <me>')      -- Silence and Poison in one
    carried[REMEDY] = nil
    eq(decide(g, cfg, blm), '/item "Echo Drops" <me>')  -- you cast: Silence before Poison
    g.me.uses_mp = false
    eq(decide(g, cfg, blm), '/item "Antidote" <me>')    -- you don't
    carried[REMEDY] = 1                                 -- Bad Breath: Remedy, then Panacea; never the Ointment
    for _, id in ipairs({ PARALYSIS, BLINDNESS, BIND, WEIGHT }) do g.me.buffs[id] = true end
    eq(decide(g, cfg, blm), '/item "Remedy" <me>')
    for _, id in ipairs({ POISON, PARALYSIS, BLINDNESS, SILENCE }) do g.me.buffs[id] = nil end
    eq(decide(g, cfg, blm), '/item "Panacea" <me>')
end)

test('items: an /item the server never answered holds the next one 4s', function ()
    local blm, cfg, mem = fake.catalog(BLM, 75, nil, 0), settings.defaults(), {}
    cfg.rows['Echo Drops'] = { on = true }
    local g = snap(nil, { items = { [ECHO_DROPS] = 3 } })
    g.me.buffs[SILENCE] = true
    local _, intent = decide(g, cfg, blm, mem)
    engine.sent(intent, g, mem)
    g.now = 1002
    eq({ decide(g, cfg, blm, mem) }, { nil, 'nothing to do' })
    g.finished = 1001  -- it went off
    eq(decide(g, cfg, blm, mem), '/item "Echo Drops" <me>')
    g.finished, g.now = nil, 1004
    eq(decide(g, cfg, blm, mem), '/item "Echo Drops" <me>')
end)

test('Chakra clears only your own poison, not a member\'s near you', function ()
    local mnk = fake.catalog(MNK, 75, nil, 0, { 'Chakra' })
    local g = snap({ { name = 'A', buffs = { [POISON] = true } } })
    eq({ decide(g, nil, mnk) }, { nil, 'nothing to do' })
    g.me.buffs[POISON] = true
    eq(decide(g, nil, mnk), '/ja "Chakra" <me>')
end)
